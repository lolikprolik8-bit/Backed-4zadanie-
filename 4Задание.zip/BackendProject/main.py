
from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy import create_engine, Column, Integer, String, Float
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from pydantic import BaseModel, Field, field_validator

from typing import Optional

app = FastAPI()

# Подключение к SQLite
DATABASE_URL = "sqlite:///./salon.db"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False}
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

Base = declarative_base()


# Модель мастера
class Master(Base):
    __tablename__ = "masters"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    specialization = Column(String, nullable=False)


# Модель услуги в базе данных
class Service(Base):
    __tablename__ = "services"

    id = Column(Integer, primary_key=True, index=True)
    category_id = Column(Integer, nullable=False)
    title = Column(String, nullable=False)
    description = Column(String, nullable=False)
    duration = Column(Integer, nullable=False)
    price = Column(Float, nullable=False)


# Pydantic-модель создания услуги
class ServiceCreate(BaseModel):
    categoryId: int
    title: str = Field(min_length=1, max_length=100)
    desc: str = Field(min_length=1, max_length=100)
    duration: int = Field(ge=30, le=180)
    price: float = Field(gt=0)

    @field_validator("title", "desc")
    @classmethod
    def check_text(cls, value):
        if not value.strip():
            raise ValueError("Поле не может быть пустым")
        return value.strip()


# Создание таблиц
Base.metadata.create_all(bind=engine)


# Подключение к базе данных
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Добавление тестовых мастеров
def add_initial_masters():
    db = SessionLocal()

    if db.query(Master).count() == 0:
        masters = [
            Master(name="Анна", specialization="Парикмахер"),
            Master(name="Мария", specialization="Визажист")
        ]

        db.add_all(masters)
        db.commit()

    db.close()


add_initial_masters()


# Категории из предыдущего задания
categories = [
    {"id": 1, "name": "Стрижки и укладки", "servicesCount": 5},
    {"id": 2, "name": "Маникюр и педикюр", "servicesCount": 5},
    {"id": 3, "name": "Брови и ресницы", "servicesCount": 4},
    {"id": 4, "name": "Спа-процедуры", "servicesCount": 4}
]


# GET /categories
@app.get("/categories")
def get_categories():
    return categories


# GET /categories/{category_id}
@app.get("/categories/{category_id}")
def get_category(category_id: int):
    for category in categories:
        if category["id"] == category_id:
            return category

    raise HTTPException(
        status_code=404,
        detail="Category not found"
    )


# GET /masters
@app.get("/masters")
def get_masters(
    specialization: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Master)

    if specialization:
        query = query.filter(
            Master.specialization == specialization
        )

    masters = query.all()

    return [
        {
            "id": master.id,
            "name": master.name,
            "specialization": master.specialization
        }
        for master in masters
    ]


# GET /masters/{master_id}
@app.get("/masters/{master_id}")
def get_master(master_id: int, db: Session = Depends(get_db)):
    master = db.query(Master).filter(
        Master.id == master_id
    ).first()

    if master is None:
        raise HTTPException(
            status_code=404,
            detail="Master not found"
        )

    return {
        "id": master.id,
        "name": master.name,
        "specialization": master.specialization
    }


# POST /services
@app.post("/services", status_code=201)
def create_service(
    service: ServiceCreate,
    db: Session = Depends(get_db)
):
    # Проверяем существование категории
    category_exists = any(
        category["id"] == service.categoryId
        for category in categories
    )

    if not category_exists:
        raise HTTPException(
            status_code=404,
            detail="Category not found"
        )

    new_service = Service(
        category_id=service.categoryId,
        title=service.title,
        description=service.desc,
        duration=service.duration,
        price=service.price
    )

    db.add(new_service)
    db.commit()
    db.refresh(new_service)

    return {
        "id": new_service.id,
        "categoryId": new_service.category_id,
        "title": new_service.title,
        "desc": new_service.description,
        "duration": new_service.duration,
        "price": new_service.price
    }
